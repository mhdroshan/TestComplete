﻿var sasTest = require("sasTest");//importing another script file. THat script file is dedicated for sas pages
//var checkOut = require("checkOut");

function kickOffTest(){
  /*
    Start doing SAS test 
  */
  
  sasTest.startSasValidation();
  //checkOut.startCheckoutValidation();
   
}